package softuni.exam.models.enums;

public enum RatingEnum {
    GOOD, BAD, UNKNOWN;
}
