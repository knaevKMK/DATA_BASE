package softuni.exam.constatnt;

public class Static {
    public static final String CAR_FILEPATH = "src/main/resources/files/json/cars.json";
    public static final String PICTURE_FILEPATH = "src/main/resources/files/json/pictures.json";
    public static final String OFFER_FILEPATH = "src/main/resources/files/xml/offers.xml";
    public static final String SELLER_FILEPATH = "src/main/resources/files/xml/sellers.xml";
}
