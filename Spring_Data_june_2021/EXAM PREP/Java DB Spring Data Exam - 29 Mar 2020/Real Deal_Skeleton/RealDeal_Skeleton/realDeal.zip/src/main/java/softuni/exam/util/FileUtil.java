package softuni.exam.util;

import java.io.IOException;

public interface FileUtil {
    String content(String path, String separtor) throws IOException;
}
