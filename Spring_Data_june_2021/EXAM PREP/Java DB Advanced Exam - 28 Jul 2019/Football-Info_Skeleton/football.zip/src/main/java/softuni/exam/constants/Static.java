package softuni.exam.constants;

public class Static {
    public static final String DIR_JSON_PATH = "src/main/resources/files/json/";
    public static final String PLAYERS_FILE = "players.json";
    public static final String DIR_XML_PATH = "src/main/resources/files/xml/";
    public static final String PICTURES_FILE = "pictures.xml";
    public static final String TEAMS_FILE = "teams.xml";
}
