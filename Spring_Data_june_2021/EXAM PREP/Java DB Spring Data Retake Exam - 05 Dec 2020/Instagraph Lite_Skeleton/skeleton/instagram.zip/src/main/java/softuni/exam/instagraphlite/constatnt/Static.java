package softuni.exam.instagraphlite.constatnt;


public class Static {
    public static final String POST_FILEPATH = "src/main/resources/files/posts.xml";
    public static final String PICTURE_FILEPATH = "src/main/resources/files/pictures.json";
    public static final String USER_FILEPATH = "src/main/resources/files/users.json";
}
