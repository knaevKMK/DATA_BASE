package com.gameHall.user.models.dto.insert;

public class OrderDto {

}
