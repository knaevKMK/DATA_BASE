package com.gameHall.user.models.entities;

public enum UserRole {
    ADMINISTRATOR, USER;
}
