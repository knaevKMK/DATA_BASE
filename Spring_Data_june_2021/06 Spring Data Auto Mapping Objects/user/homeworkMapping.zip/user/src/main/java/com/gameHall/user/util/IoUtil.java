package com.gameHall.user.util;

import java.io.IOException;

public interface IoUtil {
    String[] input()throws IOException;
    void output(String... args);
}
