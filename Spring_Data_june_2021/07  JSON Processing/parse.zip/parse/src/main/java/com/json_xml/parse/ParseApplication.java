package com.json_xml.parse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParseApplication.class, args);
	}

}
