package softuni.workshop.web.models;

public class UserRegisterModel {
    //TODO
}
