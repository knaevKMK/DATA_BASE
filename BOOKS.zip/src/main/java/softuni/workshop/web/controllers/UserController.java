package softuni.workshop.web.controllers;

public class UserController extends BaseController {
    //TODO
}
