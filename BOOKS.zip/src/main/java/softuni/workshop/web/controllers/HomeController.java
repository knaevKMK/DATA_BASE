package softuni.workshop.web.controllers;

public class HomeController extends BaseController {
    //TODO
}
