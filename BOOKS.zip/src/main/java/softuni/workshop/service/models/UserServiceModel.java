package softuni.workshop.service.models;

public class UserServiceModel {
    //TODO
}
