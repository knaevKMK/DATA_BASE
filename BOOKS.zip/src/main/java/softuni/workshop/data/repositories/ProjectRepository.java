package softuni.workshop.data.repositories;

public interface ProjectRepository {
    //TODO
}
