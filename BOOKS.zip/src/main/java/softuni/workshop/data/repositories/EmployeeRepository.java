package softuni.workshop.data.repositories;

public interface EmployeeRepository  {
    //TODO
}
