package softuni.workshop.data.repositories;


public interface CompanyRepository {
    //TODO
}
