package softuni.workshop.data.repositories;

public interface UserRepository {
    //TODO
}
