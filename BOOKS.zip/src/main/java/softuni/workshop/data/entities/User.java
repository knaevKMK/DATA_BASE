package softuni.workshop.data.entities;

public class User{
    //TODO
}
