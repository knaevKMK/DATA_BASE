package softuni.workshop.data.entities;

public class Project {
   //TODO
}
