package softuni.workshop.data.entities;

public class Company{
    //TODO
}
