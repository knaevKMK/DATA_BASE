package softuni.workshop.data.entities;

public class Employee {
    //TODO
}
