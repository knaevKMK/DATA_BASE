package softuni.workshop.data.entities;

public class Role{
    //TODO
}
